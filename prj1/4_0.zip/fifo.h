#ifndef FIFO_H
#define FIFO_H

int FIFO();

#endif

#include <stdlib.h>
#include <sys/syscall.h>
int main(){
	syscall(314, "================\n");
	return 0;
}

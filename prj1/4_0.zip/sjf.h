#ifndef SJF_H
#define SJF_H

int SJF();

#endif

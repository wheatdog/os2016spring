#ifndef RR_H
#define RR_H

int RR();

#endif

#ifndef PSJF_H
#define PSJF_H

int PSJF();

#endif
